#quick test to check if any of the packages are causing teh code crash
print("start")

print("importing matplotlib...")
import matplotlib.pyplot as plt
print("matplotlib ok")

print("importing numpy...")
import numpy as np
print("numpy ok")

print("importing shapely...")
import shapely
print("shapely ok")

print("importing shapely.ops...")
import shapely.ops
print("shapely.ops ok")

print("importing shapely.plotting...")
import shapely.plotting
print("shapely.plotting ok")

print("importing pyproj...")
from pyproj import Transformer
print("pyproj ok")

print("all imports successful")